from django.contrib import admin
from .models import teacher_detail
# Register your models here.
admin.site.register(teacher_detail)